<?php
SESSION_start();
SESSION_destroy();
echo "<script>alert('Berhasil Keluar');window.location='admin.html';</script>";
?>