<?php

$hostname = "localhost";
$user = "root";
$database = "koperasi";
$pass = "";
mysql_connect($hostname, $user, $pass);
mysql_select_db($database) or die("Connect Failed !!:".mysql_error());


?>