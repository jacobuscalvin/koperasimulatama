<?php
$sel =mysql_connect("localhost","root","");
mysql_select_db("koperasi",$sel);
?>